import React, { useState } from "react";
import GeneralInfoTab from "./tabs/GeneralInfoTab";
import VariantsTab from "./tabs/VariantsTab";
import InventoryTab from "./tabs/InventoryTab";
import MediaTab from "./tabs/MediaTab";
import AttributesTab from "./tabs/AttributesTab";

const tabLabels = ["General Info", "Variants", "Inventory", "Media", "Attributes"];

const ProductFormPage = ({ initialProduct = null }) => {
  const [activeTab, setActiveTab] = useState(0);
  const [formState, setFormState] = useState({
    product: initialProduct || {},
    variants: [],
    inventory: [],
    media: [],
    attributes: {},
  });

  const handleTabChange = (index) => setActiveTab(index);

  const handleSectionChange = (sectionKey, updatedData) => {
    setFormState((prev) => ({ ...prev, [sectionKey]: updatedData }));
  };

  const handleSubmit = () => {
    // API logic here
    console.log("Final payload:", formState);
  };

  return (
    <div className="container py-4">
      <h2>{formState.product?.product_id ? "Edit Product" : "Add Product"}</h2>

      {/* Tabs */}
      <ul className="nav nav-tabs mt-3">
        {tabLabels.map((label, i) => (
          <li className="nav-item" key={label}>
            <button
              className={`nav-link ${activeTab === i ? "active" : ""}`}
              onClick={() => handleTabChange(i)}
            >
              {label}
            </button>
          </li>
        ))}
      </ul>

      {/* Tab Content */}
      <div className="tab-content border rounded px-3 py-4 mt-2 bg-white shadow-sm">
        {activeTab === 0 && (
          <GeneralInfoTab
            data={formState.product}
            onChange={(data) => handleSectionChange("product", data)}
          />
        )}
        {activeTab === 1 && (
          <VariantsTab
            data={formState.variants}
            onChange={(data) => handleSectionChange("variants", data)}
          />
        )}
        {activeTab === 2 && (
          <InventoryTab
            data={formState.inventory}
            onChange={(data) => handleSectionChange("inventory", data)}
          />
        )}
        {activeTab === 3 && (
          <MediaTab
            data={formState.media}
            onChange={(data) => handleSectionChange("media", data)}
          />
        )}
        {activeTab === 4 && (
          <AttributesTab
            data={formState.attributes}
            onChange={(data) => handleSectionChange("attributes", data)}
          />
        )}
      </div>

      {/* Submit Button */}
      <div className="text-end mt-4">
        <button className="btn btn-primary" onClick={handleSubmit}>
          {formState.product?.product_id ? "Update Product" : "Create Product"}
        </button>
      </div>
    </div>
  );
};

export default ProductFormPage;