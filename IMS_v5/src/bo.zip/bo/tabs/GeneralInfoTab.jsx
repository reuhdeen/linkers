import React, { useState, useEffect } from "react";
import axios from "axios";
import { fetchQueryData } from "../../api/fetchData";
import { decodeBase64 } from "../../utils/decode";

const GeneralInfoTab = ({ data, onChange, isEditMode = false }) => {
  const [suppliers, setSuppliers] = useState([]);
  const [categories, setCategories] = useState([]);

  useEffect(() => {
    const token = localStorage.getItem("accessToken");
    if (!token) return;

    const loadDropdowns = async () => {
      try {
        const [supplierData, categoryData] = await Promise.all([
          fetchQueryData(token, {
            table: "suppliers",
            columns: "*",
            order: "name ASC",
          }),
          fetchQueryData(token, {
            table: "categories",
            columns: "*",
            order: "name ASC",
          }),
        ]);

        const decodedSuppliers = supplierData.map((s) => ({
          ...s,
          name: decodeBase64(s.name),
        }));

        const decodedCategories = categoryData.map((c) => ({
          ...c,
          name: decodeBase64(c.name),
        }));

        setSuppliers(decodedSuppliers);
        setCategories(decodedCategories);
      } catch (err) {
        console.error("Dropdown fetch error:", err);
      }
    };

    loadDropdowns();
  }, []);

  const handleChange = (key, value) => {
    onChange({ ...data, [key]: value });
  };

  const handleSaveGeneralInfo = async () => {
    try {
      const token = localStorage.getItem("accessToken");
      if (!token) throw new Error("No access token");

      const url = isEditMode
        ? `${process.env.REACT_APP_API_URL}/products/${data.product_id}`
        : `${process.env.REACT_APP_API_URL}/insert/products`;

      const method = isEditMode ? "put" : "post";

      const response = await axios[method](url, data, {
        headers: { Authorization: `Bearer ${token}` },
      });

      alert(isEditMode ? "Product info updated" : "Product info created");
      if (!isEditMode && response.data?.id) {
        console.log("New product ID:", response.data.id);
      }
    } catch (err) {
      console.error("Save failed:", err);
      alert("Unable to save product data.");
    }
  };

  return (
    <div className="card mb-4">
      <div className="card-body">
        <div className="row gy-3">
          <div className="col-md-6">
            <label className="form-label">Product Name</label>
            <input
              type="text"
              className="form-control"
              value={data.name || ""}
              onChange={(e) => handleChange("name", e.target.value)}
              placeholder="Enter product name"
            />
          </div>

          <div className="col-md-6">
            <label className="form-label">Brand Name</label>
            <input
              type="text"
              className="form-control"
              value={data.brand_name || ""}
              onChange={(e) => handleChange("brand_name", e.target.value)}
              placeholder="Enter brand name"
            />
          </div>

          <div className="col-md-6">
            <label className="form-label">Supplier</label>
            <select
              className="form-select"
              value={data.supplier_id || ""}
              onChange={(e) => handleChange("supplier_id", e.target.value)}
            >
              <option value="">Select supplier</option>
              {suppliers.map((s) => (
                <option key={s.supplier_id} value={s.supplier_id}>
                  {s.name}
                </option>
              ))}
            </select>
          </div>

          <div className="col-md-6">
            <label className="form-label">Category</label>
            <select
              className="form-select"
              value={data.category_id || ""}
              onChange={(e) => handleChange("category_id", e.target.value)}
            >
              <option value="">Select category</option>
              {categories.map((c) => (
                <option key={c.category_id} value={c.category_id}>
                  {c.name}
                </option>
              ))}
            </select>
          </div>

          <div className="col-md-12">
            <label className="form-label">Description</label>
            <textarea
              className="form-control"
              rows="4"
              value={data.description || ""}
              onChange={(e) => handleChange("description", e.target.value)}
              placeholder="Describe the product"
            />
          </div>

          <div className="col-md-6">
            <label className="form-label">Slug</label>
            <input
              type="text"
              className="form-control"
              value={data.slug || ""}
              onChange={(e) => handleChange("slug", e.target.value)}
              placeholder="product-name-url"
            />
          </div>

          <div className="col-md-6">
            <label className="form-label">Visibility</label>
            <select
              className="form-select"
              value={data.visibility || "public"}
              onChange={(e) => handleChange("visibility", e.target.value)}
            >
              <option value="public">Public</option>
              <option value="private">Private</option>
              <option value="archived">Archived</option>
            </select>
          </div>

          <div className="col-md-6">
            <div className="form-check mt-3">
              <input
                className="form-check-input"
                type="checkbox"
                checked={!!data.is_featured}
                onChange={(e) =>
                  handleChange("is_featured", e.target.checked ? 1 : 0)
                }
                id="is_featured"
              />
              <label className="form-check-label" htmlFor="is_featured">
                Featured Product
              </label>
            </div>
          </div>
        </div>

        <div className="text-end mt-4">
          <button
            type="button"
            className="btn btn-primary"
            onClick={handleSaveGeneralInfo}
          >
            {isEditMode ? "Update Product Info" : "Save Product Info"}
          </button>
        </div>
      </div>
    </div>
  );
};

export default GeneralInfoTab;